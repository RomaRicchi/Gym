using System.IO;
using System.Threading.Tasks;

namespace Api.Services
{
    public class LocalFileStorage : IFileStorage
    {
        private readonly string _basePath = Path.Combine(Directory.GetCurrentDirectory(), "Uploads");

        public LocalFileStorage()
        {
            if (!Directory.Exists(_basePath))
                Directory.CreateDirectory(_basePath);
        }

        public async Task<string> SaveFileAsync(Stream fileStream, string fileName, string subdirectory)
        {
            var dir = Path.Combine(_basePath, subdirectory);
            if (!Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            var path = Path.Combine(dir, fileName);
            using (var fs = new FileStream(path, FileMode.Create))
            {
                await fileStream.CopyToAsync(fs);
            }

            return Path.Combine("Uploads", subdirectory, fileName).Replace("\\", "/");
        }

        public Task<bool> DeleteFileAsync(string filePath)
        {
            try
            {
                var fullPath = Path.Combine(Directory.GetCurrentDirectory(), filePath);
                if (File.Exists(fullPath))
                {
                    File.Delete(fullPath);
                    return Task.FromResult(true);
                }
                return Task.FromResult(false);
            }
            catch
            {
                return Task.FromResult(false);
            }
        }
    }
}
