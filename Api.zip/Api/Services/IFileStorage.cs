namespace Api.Services
{
    public interface IFileStorage
    {
        Task<string> SaveFileAsync(Stream fileStream, string fileName, string subdirectory);
        Task<bool> DeleteFileAsync(string filePath);
    }
}
