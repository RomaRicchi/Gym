-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: qym _oram
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `checkin`
--

DROP TABLE IF EXISTS `checkin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `socio_id` int(10) unsigned NOT NULL,
  `turno_plantilla_id` int(10) unsigned DEFAULT NULL,
  `fecha_hora` datetime NOT NULL,
  `origen` enum('recepcion','app','dispositivo') NOT NULL DEFAULT 'recepcion',
  PRIMARY KEY (`id`),
  KEY `idx_check_socio_fecha` (`socio_id`,`fecha_hora`),
  KEY `fk_check_turno` (`turno_plantilla_id`),
  CONSTRAINT `fk_check_socio` FOREIGN KEY (`socio_id`) REFERENCES `socio` (`id`),
  CONSTRAINT `fk_check_turno` FOREIGN KEY (`turno_plantilla_id`) REFERENCES `turno_plantilla` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkin`
--

LOCK TABLES `checkin` WRITE;
/*!40000 ALTER TABLE `checkin` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comprobante`
--

DROP TABLE IF EXISTS `comprobante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comprobante` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orden_id` int(10) unsigned NOT NULL,
  `file_url` text NOT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `subido_en` datetime NOT NULL DEFAULT utc_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_comp_orden` (`orden_id`),
  CONSTRAINT `fk_comp_orden` FOREIGN KEY (`orden_id`) REFERENCES `orden_pago` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comprobante`
--

LOCK TABLES `comprobante` WRITE;
/*!40000 ALTER TABLE `comprobante` DISABLE KEYS */;
/*!40000 ALTER TABLE `comprobante` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ejercicio`
--

DROP TABLE IF EXISTS `ejercicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ejercicio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `grupo` varchar(80) DEFAULT NULL,
  `tips` text DEFAULT NULL,
  `media_url` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ejercicio`
--

LOCK TABLES `ejercicio` WRITE;
/*!40000 ALTER TABLE `ejercicio` DISABLE KEYS */;
/*!40000 ALTER TABLE `ejercicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orden_pago`
--

DROP TABLE IF EXISTS `orden_pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orden_pago` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `socio_id` int(10) unsigned NOT NULL,
  `plan_id` int(10) unsigned NOT NULL,
  `monto` decimal(12,2) NOT NULL,
  `vence_en` datetime NOT NULL,
  `estado` enum('pendiente','en_revision','verificado','rechazado','expirado') NOT NULL DEFAULT 'pendiente',
  `creado_en` datetime NOT NULL DEFAULT utc_timestamp(),
  `notas` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_orden_estado` (`estado`),
  KEY `idx_orden_socio` (`socio_id`),
  KEY `fk_orden_plan` (`plan_id`),
  CONSTRAINT `fk_orden_plan` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`id`),
  CONSTRAINT `fk_orden_socio` FOREIGN KEY (`socio_id`) REFERENCES `socio` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orden_pago`
--

LOCK TABLES `orden_pago` WRITE;
/*!40000 ALTER TABLE `orden_pago` DISABLE KEYS */;
/*!40000 ALTER TABLE `orden_pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orden_turno`
--

DROP TABLE IF EXISTS `orden_turno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orden_turno` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orden_id` int(10) unsigned NOT NULL,
  `turno_plantilla_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_orden_turno` (`orden_id`,`turno_plantilla_id`),
  KEY `fk_ot_turno` (`turno_plantilla_id`),
  CONSTRAINT `fk_ot_orden` FOREIGN KEY (`orden_id`) REFERENCES `orden_pago` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ot_turno` FOREIGN KEY (`turno_plantilla_id`) REFERENCES `turno_plantilla` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orden_turno`
--

LOCK TABLES `orden_turno` WRITE;
/*!40000 ALTER TABLE `orden_turno` DISABLE KEYS */;
/*!40000 ALTER TABLE `orden_turno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plan`
--

DROP TABLE IF EXISTS `plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  `dias_por_semana` int(11) NOT NULL CHECK (`dias_por_semana` in (2,3,5)),
  `precio` decimal(12,2) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plan`
--

LOCK TABLES `plan` WRITE;
/*!40000 ALTER TABLE `plan` DISABLE KEYS */;
INSERT INTO `plan` VALUES (1,'Plan Básico 2x',2,12000.00,1),(2,'Plan Standard 3x',3,15000.00,1),(3,'Plan Full 5x',5,20000.00,1);
/*!40000 ALTER TABLE `plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profesor`
--

DROP TABLE IF EXISTS `profesor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profesor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(160) NOT NULL,
  `email` varchar(320) DEFAULT NULL,
  `estado` enum('activo','inactivo') NOT NULL DEFAULT 'activo',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profesor`
--

LOCK TABLES `profesor` WRITE;
/*!40000 ALTER TABLE `profesor` DISABLE KEYS */;
INSERT INTO `profesor` VALUES (1,'Lourdes','lourdes@gym.local','activo');
/*!40000 ALTER TABLE `profesor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registro_entrenamiento`
--

DROP TABLE IF EXISTS `registro_entrenamiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `registro_entrenamiento` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rutina_asignada_id` int(10) unsigned NOT NULL,
  `fecha` date NOT NULL,
  `observaciones` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_reg_ruta` (`rutina_asignada_id`),
  CONSTRAINT `fk_reg_ruta` FOREIGN KEY (`rutina_asignada_id`) REFERENCES `rutina_asignada` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registro_entrenamiento`
--

LOCK TABLES `registro_entrenamiento` WRITE;
/*!40000 ALTER TABLE `registro_entrenamiento` DISABLE KEYS */;
/*!40000 ALTER TABLE `registro_entrenamiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registro_item`
--

DROP TABLE IF EXISTS `registro_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `registro_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `registro_id` int(10) unsigned NOT NULL,
  `ejercicio_id` int(10) unsigned DEFAULT NULL,
  `series` int(11) DEFAULT NULL,
  `repeticiones` int(11) DEFAULT NULL,
  `carga` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_rit_reg` (`registro_id`),
  KEY `fk_rit_ej` (`ejercicio_id`),
  CONSTRAINT `fk_rit_ej` FOREIGN KEY (`ejercicio_id`) REFERENCES `ejercicio` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rit_reg` FOREIGN KEY (`registro_id`) REFERENCES `registro_entrenamiento` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registro_item`
--

LOCK TABLES `registro_item` WRITE;
/*!40000 ALTER TABLE `registro_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `registro_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rutina_asignada`
--

DROP TABLE IF EXISTS `rutina_asignada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rutina_asignada` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `socio_id` int(10) unsigned NOT NULL,
  `rutina_id` int(10) unsigned NOT NULL,
  `inicio` date NOT NULL,
  `fin` date DEFAULT NULL,
  `notas` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ruta_socio` (`socio_id`),
  KEY `fk_ruta_plant` (`rutina_id`),
  CONSTRAINT `fk_ruta_plant` FOREIGN KEY (`rutina_id`) REFERENCES `rutina_plantilla` (`id`),
  CONSTRAINT `fk_ruta_socio` FOREIGN KEY (`socio_id`) REFERENCES `socio` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rutina_asignada`
--

LOCK TABLES `rutina_asignada` WRITE;
/*!40000 ALTER TABLE `rutina_asignada` DISABLE KEYS */;
/*!40000 ALTER TABLE `rutina_asignada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rutina_plantilla`
--

DROP TABLE IF EXISTS `rutina_plantilla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rutina_plantilla` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `objetivo` varchar(120) DEFAULT NULL,
  `plan_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_rutpla_plan` (`plan_id`),
  CONSTRAINT `fk_rutpla_plan` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rutina_plantilla`
--

LOCK TABLES `rutina_plantilla` WRITE;
/*!40000 ALTER TABLE `rutina_plantilla` DISABLE KEYS */;
/*!40000 ALTER TABLE `rutina_plantilla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rutina_plantilla_ejercicio`
--

DROP TABLE IF EXISTS `rutina_plantilla_ejercicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rutina_plantilla_ejercicio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rutina_id` int(10) unsigned NOT NULL,
  `ejercicio_id` int(10) unsigned NOT NULL,
  `orden` int(11) NOT NULL DEFAULT 1,
  `series` int(11) DEFAULT NULL,
  `repeticiones` int(11) DEFAULT NULL,
  `descanso_seg` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rutpla_ej` (`rutina_id`,`ejercicio_id`),
  KEY `fk_rpe_ejercicio` (`ejercicio_id`),
  CONSTRAINT `fk_rpe_ejercicio` FOREIGN KEY (`ejercicio_id`) REFERENCES `ejercicio` (`id`),
  CONSTRAINT `fk_rpe_rutina` FOREIGN KEY (`rutina_id`) REFERENCES `rutina_plantilla` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rutina_plantilla_ejercicio`
--

LOCK TABLES `rutina_plantilla_ejercicio` WRITE;
/*!40000 ALTER TABLE `rutina_plantilla_ejercicio` DISABLE KEYS */;
/*!40000 ALTER TABLE `rutina_plantilla_ejercicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sala`
--

DROP TABLE IF EXISTS `sala`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sala` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  `capacidad` int(11) NOT NULL CHECK (`capacidad` > 0),
  `activa` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sala`
--

LOCK TABLES `sala` WRITE;
/*!40000 ALTER TABLE `sala` DISABLE KEYS */;
INSERT INTO `sala` VALUES (1,'Sala Principal',20,1);
/*!40000 ALTER TABLE `sala` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `socio`
--

DROP TABLE IF EXISTS `socio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `socio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dni` varchar(32) NOT NULL,
  `nombre` varchar(160) NOT NULL,
  `email` varchar(320) NOT NULL,
  `telefono` varchar(64) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` datetime NOT NULL DEFAULT utc_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `dni` (`dni`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `socio`
--

LOCK TABLES `socio` WRITE;
/*!40000 ALTER TABLE `socio` DISABLE KEYS */;
INSERT INTO `socio` VALUES (1,'30111222','Rocío Herrera','rocio.herrera@example.com','+54 261 555-1001',1,'2025-08-24 20:40:40'),(2,'32222333','Tomás Lucero','tomas.lucero@example.com','+54 261 555-1002',1,'2025-08-24 20:40:40'),(3,'33444555','Malena Rivas','malena.rivas@example.com','+54 261 555-1003',1,'2025-08-24 20:40:40'),(4,'35666777','Ariel Quiroga','ariel.quiroga@example.com','+54 261 555-1004',1,'2025-08-24 20:40:40'),(5,'37888999','Natalia Moyano','natalia.moyano@example.com','+54 261 555-1005',1,'2025-08-24 20:40:40');
/*!40000 ALTER TABLE `socio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suscripcion`
--

DROP TABLE IF EXISTS `suscripcion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suscripcion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `socio_id` int(10) unsigned NOT NULL,
  `plan_id` int(10) unsigned NOT NULL,
  `inicio` datetime NOT NULL,
  `fin` datetime NOT NULL,
  `estado` enum('activa','vencida','cancelada') NOT NULL DEFAULT 'activa',
  `creado_en` datetime NOT NULL DEFAULT utc_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_sus_socio` (`socio_id`),
  KEY `fk_sus_plan` (`plan_id`),
  CONSTRAINT `fk_sus_plan` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`id`),
  CONSTRAINT `fk_sus_socio` FOREIGN KEY (`socio_id`) REFERENCES `socio` (`id`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`fin` > `inicio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suscripcion`
--

LOCK TABLES `suscripcion` WRITE;
/*!40000 ALTER TABLE `suscripcion` DISABLE KEYS */;
/*!40000 ALTER TABLE `suscripcion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suscripcion_turno`
--

DROP TABLE IF EXISTS `suscripcion_turno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suscripcion_turno` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suscripcion_id` int(10) unsigned NOT NULL,
  `turno_plantilla_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sus_turno` (`suscripcion_id`,`turno_plantilla_id`),
  KEY `fk_sust_turno` (`turno_plantilla_id`),
  CONSTRAINT `fk_sust_sus` FOREIGN KEY (`suscripcion_id`) REFERENCES `suscripcion` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sust_turno` FOREIGN KEY (`turno_plantilla_id`) REFERENCES `turno_plantilla` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suscripcion_turno`
--

LOCK TABLES `suscripcion_turno` WRITE;
/*!40000 ALTER TABLE `suscripcion_turno` DISABLE KEYS */;
/*!40000 ALTER TABLE `suscripcion_turno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `turno_plantilla`
--

DROP TABLE IF EXISTS `turno_plantilla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `turno_plantilla` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sala_id` int(10) unsigned NOT NULL,
  `profesor_id` int(10) unsigned DEFAULT NULL,
  `dia_semana` tinyint(4) NOT NULL CHECK (`dia_semana` between 0 and 6),
  `hora_inicio` time NOT NULL,
  `duracion_min` int(11) NOT NULL CHECK (`duracion_min` between 15 and 240),
  `cupo` int(11) NOT NULL CHECK (`cupo` > 0),
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_turno` (`dia_semana`,`hora_inicio`,`sala_id`),
  KEY `fk_turno_sala` (`sala_id`),
  KEY `fk_turno_profesor` (`profesor_id`),
  CONSTRAINT `fk_turno_profesor` FOREIGN KEY (`profesor_id`) REFERENCES `profesor` (`id`),
  CONSTRAINT `fk_turno_sala` FOREIGN KEY (`sala_id`) REFERENCES `sala` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `turno_plantilla`
--

LOCK TABLES `turno_plantilla` WRITE;
/*!40000 ALTER TABLE `turno_plantilla` DISABLE KEYS */;
INSERT INTO `turno_plantilla` VALUES (1,1,1,1,'19:00:00',60,20,1),(2,1,1,3,'19:00:00',60,20,1),(3,1,1,5,'19:00:00',60,20,1),(4,1,1,2,'19:00:00',60,20,1),(5,1,1,4,'19:00:00',60,20,1);
/*!40000 ALTER TABLE `turno_plantilla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(320) NOT NULL,
  `password_hash` text NOT NULL,
  `rol` enum('admin','recepcion','profesor') NOT NULL,
  `estado` enum('activo','inactivo') NOT NULL DEFAULT 'activo',
  `creado_en` datetime NOT NULL DEFAULT utc_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_checkin_hoy_ar`
--

DROP TABLE IF EXISTS `v_checkin_hoy_ar`;
/*!50001 DROP VIEW IF EXISTS `v_checkin_hoy_ar`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_checkin_hoy_ar` AS SELECT 
 1 AS `id`,
 1 AS `socio_id`,
 1 AS `turno_plantilla_id`,
 1 AS `fecha_ar`,
 1 AS `origen`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_cupo_reservado`
--

DROP TABLE IF EXISTS `v_cupo_reservado`;
/*!50001 DROP VIEW IF EXISTS `v_cupo_reservado`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_cupo_reservado` AS SELECT 
 1 AS `turno_id`,
 1 AS `dia_semana`,
 1 AS `hora_inicio`,
 1 AS `cupo`,
 1 AS `reservados`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_ocupacion_hoy`
--

DROP TABLE IF EXISTS `v_ocupacion_hoy`;
/*!50001 DROP VIEW IF EXISTS `v_ocupacion_hoy`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_ocupacion_hoy` AS SELECT 
 1 AS `turno_id`,
 1 AS `fecha`,
 1 AS `asistencias`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_ordenes_ar`
--

DROP TABLE IF EXISTS `v_ordenes_ar`;
/*!50001 DROP VIEW IF EXISTS `v_ordenes_ar`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_ordenes_ar` AS SELECT 
 1 AS `id`,
 1 AS `socio_id`,
 1 AS `plan_id`,
 1 AS `monto`,
 1 AS `estado`,
 1 AS `vence_en_ar`,
 1 AS `creado_en`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_suscripciones_ar`
--

DROP TABLE IF EXISTS `v_suscripciones_ar`;
/*!50001 DROP VIEW IF EXISTS `v_suscripciones_ar`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_suscripciones_ar` AS SELECT 
 1 AS `id`,
 1 AS `socio_id`,
 1 AS `plan_id`,
 1 AS `inicio_ar`,
 1 AS `fin_ar`,
 1 AS `estado`,
 1 AS `creado_en`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_checkin_hoy_ar`
--

/*!50001 DROP VIEW IF EXISTS `v_checkin_hoy_ar`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_checkin_hoy_ar` AS select `c`.`id` AS `id`,`c`.`socio_id` AS `socio_id`,`c`.`turno_plantilla_id` AS `turno_plantilla_id`,convert_tz(`c`.`fecha_hora`,'+00:00','-03:00') AS `fecha_ar`,`c`.`origen` AS `origen` from `checkin` `c` where cast(convert_tz(`c`.`fecha_hora`,'+00:00','-03:00') as date) = curdate() */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_cupo_reservado`
--

/*!50001 DROP VIEW IF EXISTS `v_cupo_reservado`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_cupo_reservado` AS select `t`.`id` AS `turno_id`,`t`.`dia_semana` AS `dia_semana`,`t`.`hora_inicio` AS `hora_inicio`,`t`.`cupo` AS `cupo`,count(`st`.`id`) AS `reservados` from ((`turno_plantilla` `t` left join `suscripcion_turno` `st` on(`st`.`turno_plantilla_id` = `t`.`id`)) left join `suscripcion` `s` on(`s`.`id` = `st`.`suscripcion_id` and `s`.`estado` = 'activa' and current_timestamp() between `s`.`inicio` and `s`.`fin`)) group by `t`.`id`,`t`.`dia_semana`,`t`.`hora_inicio`,`t`.`cupo` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ocupacion_hoy`
--

/*!50001 DROP VIEW IF EXISTS `v_ocupacion_hoy`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ocupacion_hoy` AS select `t`.`id` AS `turno_id`,cast(`c`.`fecha_hora` as date) AS `fecha`,count(`c`.`id`) AS `asistencias` from (`turno_plantilla` `t` left join `checkin` `c` on(`c`.`turno_plantilla_id` = `t`.`id` and cast(`c`.`fecha_hora` as date) = curdate())) group by `t`.`id`,cast(`c`.`fecha_hora` as date) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ordenes_ar`
--

/*!50001 DROP VIEW IF EXISTS `v_ordenes_ar`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ordenes_ar` AS select `o`.`id` AS `id`,`o`.`socio_id` AS `socio_id`,`o`.`plan_id` AS `plan_id`,`o`.`monto` AS `monto`,`o`.`estado` AS `estado`,convert_tz(`o`.`vence_en`,'+00:00','-03:00') AS `vence_en_ar`,`o`.`creado_en` AS `creado_en` from `orden_pago` `o` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_suscripciones_ar`
--

/*!50001 DROP VIEW IF EXISTS `v_suscripciones_ar`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_suscripciones_ar` AS select `s`.`id` AS `id`,`s`.`socio_id` AS `socio_id`,`s`.`plan_id` AS `plan_id`,convert_tz(`s`.`inicio`,'+00:00','-03:00') AS `inicio_ar`,convert_tz(`s`.`fin`,'+00:00','-03:00') AS `fin_ar`,`s`.`estado` AS `estado`,`s`.`creado_en` AS `creado_en` from `suscripcion` `s` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-01 22:46:57
